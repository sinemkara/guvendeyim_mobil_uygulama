package com.example.guvendeyim;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class guvende_degilim extends AppCompatActivity implements LocationListener {
    EditText edt_ad,edt_soyad,edt_mesaj,edt_ad2,edt_soyad2,edt_tel;
    LocationManager locationManager;
    Button gonder,sil;
    TextView textView, txt_Enlem, txt_Boylam,maps;
    String provider;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guvende_degilim);
        //kendi oluşturduğumuz tanımlamaları yaptığımız yer
        tanim();


        //MESAJ KAYIT ADINDA TABLOMUZ OLUŞTURULDU
        //MESAJ KAYITTAKİ DEĞİŞKENLER EKLENDİ
        //sqlite da string karakteri '' diye tanımlanır

        try {
            final SQLiteDatabase sqLiteDatabase=this.openOrCreateDatabase("kayıt",MODE_PRIVATE,null);
            sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS MESAJ_KAYİT(ad VARCHAR,soyad VARCHAR,mesaj VARCHAR,ad2 VARCHAR,soyad2 VARCHAR,tel INT)");

            //Veriler edittexte yazılacak
            // sqLiteDatabase.execSQL("Insert INTO MESAJ_KAYİT(ad,soyad,mesaj,ad2,soyad2,tel)" +
            //        "VALUES('Sinem','KARA','Güvendeyim','AHMET','KARA',5051544288)");

            //VERİLER DATABASEDAN OKUNUR
            Cursor cursor = sqLiteDatabase.rawQuery("Select * from MESAJ_KAYİT",null);
            final int adx=cursor.getColumnIndex("ad");
            int soyadx=cursor.getColumnIndex("soyad");
            int mesajx=cursor.getColumnIndex("mesaj");
            int ad2x=cursor.getColumnIndex("ad2");
            int soyad2x=cursor.getColumnIndex("soyad2");
            int telx=cursor.getColumnIndex("tel");

            //DAHA ÖNCEKİ VERİLERİ GÖSTERME
            while (cursor.moveToNext()) {
                textView.append(
                        cursor.getString(adx).trim()+ "" +
                                cursor.getString(soyadx).trim() + "" +
                                cursor.getString(mesajx).trim() + "" +
                                cursor.getString(ad2x).trim() + "" +
                                cursor.getString(soyad2x).trim() + "" +
                                cursor.getInt(telx) + "\n");
            }
            cursor.close();

            //"MESAJ_KAYİT" adlı tabloya veri eklenmesi
            gonder.setOnClickListener(new View.OnClickListener() {
                @SuppressLint("SetTextI18n")
                @Override
                public void onClick(View v) {

                    sqLiteDatabase.execSQL("INSERT INTO MESAJ_KAYİT(ad, soyad, mesaj, ad2, soyad2, tel) VALUES('" +
                            edt_ad.getText().toString() +"','" +
                            edt_soyad.getText().toString()+"','" +
                            edt_mesaj.getText().toString()+"','" +
                            edt_ad2.getText().toString()+"','" +
                            edt_soyad2.getText().toString()+"','" +
                            edt_tel .getText().toString() +"')");

                    if (TextUtils.isEmpty(edt_ad.getText().toString().trim()) ||
                            TextUtils.isEmpty(edt_soyad.getText().toString().trim()) ||
                            TextUtils.isEmpty(edt_mesaj.getText().toString().trim()) ||
                            TextUtils.isEmpty(edt_ad2.getText().toString().trim()) ||
                            TextUtils.isEmpty(edt_soyad2.getText().toString().trim()) ||
                            TextUtils.isEmpty(edt_tel.getText().toString().trim())) {

                        // Kullanıcıya hata mesajını göster
                        Toast.makeText(getApplicationContext(), "Tüm alanları doldurun", Toast.LENGTH_SHORT).show();
                    } else {
                        // Kayıt başarılı durumu
                        Toast.makeText(getApplicationContext(), "Kayıt başarılı", Toast.LENGTH_LONG).show();

                    }

                    edt_ad.setText("");
                    edt_soyad.setText("");
                    edt_mesaj.setText("");
                    edt_ad2.setText(" ");
                    edt_soyad2.setText("");
                    edt_tel.setText("");


                    Cursor cursor = sqLiteDatabase.rawQuery("Select * from MESAJ_KAYİT",null);
                    final int adx=cursor.getColumnIndex("ad");
                    int soyadx=cursor.getColumnIndex("soyad");
                    int mesajx=cursor.getColumnIndex("mesaj");
                    int ad2x=cursor.getColumnIndex("ad2");
                    int soyad2x=cursor.getColumnIndex("soyad2");
                    int telx=cursor.getColumnIndex("tel");

                    //DAHA ÖNCEKİ VERİLERİ GÖSTERME
                    while (cursor.moveToNext()){
                        textView.append(
                                cursor.getString(adx).trim()+"\n"+
                                        cursor.getString(soyadx)+"\n"+
                                        cursor.getString(mesajx)+"\n"+
                                        cursor.getString(ad2x)+"\n"+
                                        cursor.getString(soyad2x)+"\n"+
                                        cursor.getInt(telx)+"");
                    }
                    cursor.close();



                }
            });
            sil.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    textView.setText("");
                    sqLiteDatabase.execSQL("DROP TABLE IF EXISTS MESAJ_KAYİT");
                    sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS MESAJ_KAYİT(ad VARCHAR, soyad VARCHAR, mesaj VARCHAR, ad2 VARCHAR, soyad2 VARCHAR, tel INT)");
                }
            });

        }catch (Exception e){
            e.printStackTrace();
        }

    }

    //DATA OLUŞTURMA KISMIDIR
    private void tanim() {
        edt_ad=findViewById(R.id.edt_ad);
        edt_soyad=findViewById(R.id.edt_soyad);
        edt_mesaj=findViewById(R.id.edt_mesaj);
        edt_ad2=findViewById(R.id.edt_ad2);
        edt_soyad2=findViewById(R.id.edt_soyad2);
        edt_tel=findViewById(R.id.edt_tel);
        gonder=findViewById(R.id.gonder);
        textView=findViewById(R.id.textView);
        sil=findViewById(R.id.sil);
        sil = findViewById(R.id.sil);
        txt_Enlem = findViewById(R.id.txt_Enlem);
        txt_Boylam = findViewById(R.id.txt_Boylam);
        maps=findViewById(R.id.maps);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        Criteria criteria = new Criteria();
        provider = locationManager.getBestProvider(criteria, false);
        //İZİN KONTROL YERİDİR.NEREDE İZİN VERİLMESİ GEREKTİĞİNİ YAZAR
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        /*Location location = locationManager.getLastKnownLocation(provider);
        if (location != null) {
            //onLocationChanged
        } else {
            txt_Enlem.setText("Not avaliable");
            txt_Boylam.setText("Not avaliable");
        }*/
        Location location = locationManager.getLastKnownLocation(provider);
        if (location != null) {
            // Konum bilgisi mevcutsa
            double lat = location.getLatitude();
            double log = location.getLongitude();
            txt_Enlem.setText(String.valueOf(lat));
            txt_Boylam.setText(String.valueOf(log));
        } else {
            // Konum bilgisi mevcut değilse
            txt_Enlem.setText("Not available");
            txt_Boylam.setText("Not available");
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        //Cihazın belirlenen zaman içerisinde en az belirlenen miktarda yer değiştirilkmesi
        // halinde aktif lokasyon verilerinin alınmasını sağlar
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        locationManager.requestLocationUpdates(provider, 100, 1, this);
    }

    @Override
    protected void onPause() {
        //Uygulama durduğunda konum bilgisini alınmaması için
        super.onPause();
        //Üstte LocationListener hizalandığı için tekrardan çağrılmıyor
        locationManager.removeUpdates(this);
    }


    @Override
    public void onLocationChanged(@NonNull Location location) {
        //Konum güncellenmesi geldiğinde tetiklenir.Parametre olarak location var
        double lat= location.getLatitude();//Boylam
        double log= location.getLongitude();//boylam değerini elde etmek için kullanılan bir metottur.
        txt_Enlem.setText(String.valueOf(lat));
        txt_Boylam.setText(String.valueOf(log));

        // Enlem bilgisini güncelle
        txt_Enlem.setText(String.valueOf(lat));

        // Google Haritalar linki oluştur
        final String googleMapsLink = "http://maps.google.com/maps?q=" + lat + "," + log;

        // Tıklanabilir linki hazırla
        SpannableString spannableString = new SpannableString("KONUM LİNKİ: " + googleMapsLink);
        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                // Link tıklandığında yapılacak işlemler
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(googleMapsLink));
                startActivity(intent);
            }
        };

        // Linkin belirli bir konumdan başlamasını sağla
        // int start = "Konum Linki: ".length();
        int start =0;
        spannableString.setSpan(clickableSpan, start, start + googleMapsLink.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        // Linki ekleyip tıklanabilir yap
        maps.setText(spannableString);

        // Sola hizalama ekleyerek görüntüyü güncelle
        maps.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        maps.setMovementMethod(LinkMovementMethod.getInstance());

    }

    @Override
    //Konum bilgisi veren servistir
    public void onStatusChanged(String provider, int status, Bundle extras) {
        LocationListener.super.onStatusChanged(provider, status, extras);
    }

    @Override
    //Aktif Servis sağlayıcısıdır
    public void onProviderEnabled(@NonNull String provider) {
        LocationListener.super.onProviderEnabled(provider);

        Toast.makeText(this, "Enable Provider", Toast.LENGTH_SHORT).show();
    }

    @Override
    //Pasif Servis sağlayıcısıdır
    public void onProviderDisabled(@NonNull String provider) {
        LocationListener.super.onProviderDisabled(provider);

        Toast.makeText(this, "Disable Provider", Toast.LENGTH_SHORT).show();
    }
}
