package com.example.guvendeyim;

import static android.text.TextUtils.isEmpty;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import java.text.BreakIterator;

public class MainActivity extends AppCompatActivity {
ImageButton guvende;
Button guvende_degil;
EditText edt_ad;
    @SuppressLint({"WrongViewCast", "MissingInflatedId"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        guvende=findViewById(R.id.guvende);
        guvende_degil=findViewById(R.id.guvende_degil);
        edt_ad=findViewById(R.id.edt_ad);



        guvende.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                //Intent x=new Intent(MainActivity.this, guvendeyim.class);
                //startActivity(x);
            }
        });
        guvende_degil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent x=new Intent(MainActivity.this,guvende_degilim.class);
                startActivity(x);
            }
        });

    }
}